import { MotionConfig } from 'framer-motion';
import ScrollProgress from '@/components/ScrollProgress';
import '@/components/office3d/office3d.css';
import React, { lazy, Suspense } from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';

const OfficeExperience = lazy(() => import('@/components/office3d/OfficeExperience'));

function App() {
    return (
        <MotionConfig reducedMotion="user">
            <Suspense fallback={<div className="office-background office-fallback" aria-hidden="true" />}>
                <OfficeExperience />
            </Suspense>
            <div className="site-over-3d">
                <Router>
                    <ScrollProgress />
                    <ScrollToTop />
                    <Routes>
                        <Route path="/" element={<HomePage />} />
                    </Routes>
                </Router>
            </div>
        </MotionConfig>
    );
}

export default App;
