/* eslint-disable react/no-unknown-property */
import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Float, RoundedBox } from '@react-three/drei';
import { MathUtils, Vector3 } from 'three';

const WOOD = '#654631';
const DARK_WOOD = '#30231c';
const CREAM = '#d8c9b3';
const COPPER = '#a96f4f';
const OLIVE = '#697557';

function Material({ color, roughness = 0.72, metalness = 0.05, emissive, emissiveIntensity = 0 }) {
  return (
    <meshStandardMaterial
      color={color}
      roughness={roughness}
      metalness={metalness}
      emissive={emissive || '#000000'}
      emissiveIntensity={emissiveIntensity}
    />
  );
}

function City({ simple }) {
  const buildings = useMemo(() => Array.from({ length: simple ? 14 : 30 }, (_, index) => {
    const row = index % 3;
    const x = ((index * 2.73) % 14) - 7;
    const height = 1.1 + ((index * 1.47) % 4.8);
    return {
      x,
      y: height / 2,
      z: -8.5 - row * 2.2,
      width: 0.55 + ((index * 0.37) % 1.1),
      height,
      tone: index % 4 === 0 ? '#77858a' : index % 3 === 0 ? '#9a8f82' : '#6d777b',
    };
  }), [simple]);

  return (
    <group>
      <mesh position={[0, 3.2, -13]}>
        <planeGeometry args={[28, 12]} />
        <meshBasicMaterial color="#b7d2d6" />
      </mesh>
      {buildings.map((building, index) => (
        <mesh key={index} position={[building.x, building.y, building.z]}>
          <boxGeometry args={[building.width, building.height, 1.2]} />
          <Material color={building.tone} roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

function WindowWall({ simple }) {
  return (
    <group>
      <City simple={simple} />
      <mesh position={[-5.1, 2.7, -4.9]}><boxGeometry args={[2.2, 5.4, 0.35]} /><Material color={DARK_WOOD} /></mesh>
      <mesh position={[5.1, 2.7, -4.9]}><boxGeometry args={[2.2, 5.4, 0.35]} /><Material color={DARK_WOOD} /></mesh>
      <mesh position={[0, 5.15, -4.9]}><boxGeometry args={[8.2, 0.5, 0.35]} /><Material color={DARK_WOOD} /></mesh>
      <mesh position={[0, 0.25, -4.9]}><boxGeometry args={[8.2, 0.55, 0.35]} /><Material color={DARK_WOOD} /></mesh>
      {[-2.65, 0, 2.65].map(x => (
        <mesh key={x} position={[x, 2.75, -4.65]}><boxGeometry args={[0.16, 4.6, 0.16]} /><Material color="#17191a" metalness={0.55} roughness={0.28} /></mesh>
      ))}
      <mesh position={[0, 2.75, -4.7]}>
        <planeGeometry args={[8.1, 4.55]} />
        <meshPhysicalMaterial color="#91b6bd" transparent opacity={0.16} roughness={0.05} metalness={0.08} transmission={0.2} />
      </mesh>
    </group>
  );
}

function Shelves() {
  return (
    <group position={[-4.55, 2.5, -4.25]}>
      <mesh><boxGeometry args={[1.9, 4.7, 0.55]} /><Material color={WOOD} /></mesh>
      {[1.65, 0.35, -0.95].map(y => (
        <mesh key={y} position={[0, y, 0.38]}><boxGeometry args={[1.85, 0.12, 0.8]} /><Material color="#805b3e" /></mesh>
      ))}
      {[-0.55, -0.22, 0.1, 0.48].map((x, index) => (
        <mesh key={x} position={[x, 1.93, 0.55]} rotation={[0, 0, index % 2 ? -0.08 : 0.03]}>
          <boxGeometry args={[0.22, 0.72 - index * 0.04, 0.36]} /><Material color={index % 2 ? COPPER : CREAM} />
        </mesh>
      ))}
      <Plant position={[0.48, 0.62, 0.55]} scale={0.7} />
    </group>
  );
}

function Plant({ position = [0, 0, 0], scale = 1 }) {
  const leaves = useMemo(() => Array.from({ length: 9 }, (_, index) => ({
    x: Math.sin(index * 2.4) * (0.2 + (index % 3) * 0.09),
    y: 0.55 + (index % 4) * 0.18,
    z: Math.cos(index * 2.4) * 0.2,
    rotation: [Math.sin(index) * 0.5, index * 0.8, Math.cos(index) * 0.45],
  })), []);
  return (
    <group position={position} scale={scale}>
      <mesh position={[0, 0.25, 0]}><cylinderGeometry args={[0.28, 0.22, 0.5, 20]} /><Material color="#7b5339" roughness={0.95} /></mesh>
      <mesh position={[0, 0.65, 0]}><cylinderGeometry args={[0.025, 0.04, 0.85, 8]} /><Material color="#40513b" /></mesh>
      {leaves.map((leaf, index) => (
        <mesh key={index} position={[leaf.x, leaf.y, leaf.z]} rotation={leaf.rotation}>
          <sphereGeometry args={[0.18, 12, 8]} />
          <meshStandardMaterial color={index % 3 === 0 ? '#84926c' : OLIVE} roughness={0.9} />
        </mesh>
      ))}
    </group>
  );
}

function Monitor() {
  return (
    <group position={[-0.7, 2.15, -0.35]} rotation={[0, 0.08, 0]}>
      <RoundedBox args={[3.45, 2.12, 0.2]} radius={0.08} smoothness={3}>
        <Material color="#151617" metalness={0.65} roughness={0.25} />
      </RoundedBox>
      <mesh position={[0, 0, 0.108]}>
        <planeGeometry args={[3.18, 1.82]} />
        <meshStandardMaterial color="#674b36" emissive="#3e281b" emissiveIntensity={0.55} roughness={0.48} />
      </mesh>
      <mesh position={[-0.88, 0.18, 0.116]}><planeGeometry args={[1.12, 0.8]} /><meshBasicMaterial color="#d7c6aa" /></mesh>
      <mesh position={[0.73, 0.22, 0.117]}><planeGeometry args={[1.72, 0.72]} /><meshBasicMaterial color="#8b684c" /></mesh>
      <mesh position={[0.7, -0.45, 0.118]}><planeGeometry args={[1.75, 0.16]} /><meshBasicMaterial color="#b28765" /></mesh>
      <mesh position={[0, -1.45, -0.02]}><cylinderGeometry args={[0.13, 0.18, 0.9, 16]} /><Material color="#28292a" metalness={0.7} roughness={0.25} /></mesh>
      <mesh position={[0, -1.9, 0.1]}><boxGeometry args={[1.25, 0.08, 0.65]} /><Material color="#242526" metalness={0.72} roughness={0.25} /></mesh>
    </group>
  );
}

function Laptop() {
  return (
    <group position={[2.3, 1.08, 0.3]} rotation={[0, -0.2, 0]}>
      <mesh position={[0, 0.06, 0.25]} rotation={[-0.05, 0, 0]}><boxGeometry args={[1.9, 0.1, 1.25]} /><Material color="#a6a3a0" metalness={0.7} roughness={0.28} /></mesh>
      <group position={[0, 0.83, -0.3]} rotation={[-0.12, 0, 0]}>
        <RoundedBox args={[1.9, 1.35, 0.1]} radius={0.06} smoothness={2}><Material color="#9d9b98" metalness={0.65} roughness={0.3} /></RoundedBox>
        <mesh position={[0, 0, 0.056]}><planeGeometry args={[1.72, 1.15]} /><meshStandardMaterial color="#283433" emissive="#1c4038" emissiveIntensity={0.55} /></mesh>
        {[0.25, 0, -0.25].map((y, index) => <mesh key={y} position={[0.2, y, 0.06]}><planeGeometry args={[1.05 - index * 0.14, 0.08]} /><meshBasicMaterial color={index === 0 ? '#d0b38f' : '#829a80'} /></mesh>)}
      </group>
    </group>
  );
}

function Desk({ simple }) {
  return (
    <group>
      <RoundedBox args={[8.4, 0.24, 3.2]} radius={0.1} smoothness={3} position={[0, 0.88, 0.45]} receiveShadow castShadow={!simple}>
        <Material color="#b8aaa0" roughness={0.42} metalness={0.12} />
      </RoundedBox>
      {[-3.55, 3.55].flatMap(x => [-0.55, 1.45].map(z => (
        <mesh key={`${x}-${z}`} position={[x, 0.42, z]} castShadow={!simple}><boxGeometry args={[0.16, 0.85, 0.16]} /><Material color="#222323" metalness={0.7} roughness={0.28} /></mesh>
      )))}
      <Monitor />
      <Laptop />
      <mesh position={[-0.6, 1.05, 1.65]} rotation={[0, 0.04, 0]}><boxGeometry args={[2.45, 0.08, 0.62]} /><Material color="#d8d5cf" roughness={0.42} /></mesh>
      {!simple && Array.from({ length: 12 }, (_, index) => (
        <mesh key={index} position={[-1.52 + index * 0.17, 1.1, 1.58]}><boxGeometry args={[0.12, 0.025, 0.38]} /><Material color="#85817b" roughness={0.55} /></mesh>
      ))}
      <mesh position={[0.75, 1.02, 1.56]}><sphereGeometry args={[0.22, 20, 12, 0, Math.PI]} /><Material color="#e3ded7" roughness={0.45} /></mesh>
      <mesh position={[-3.05, 1.35, 0.9]}><cylinderGeometry args={[0.35, 0.31, 0.9, 24]} /><Material color="#2b2b29" roughness={0.78} /></mesh>
      <mesh position={[-3.05, 1.84, 0.9]}><torusGeometry args={[0.27, 0.04, 10, 24]} /><Material color="#3c3b37" /></mesh>
      <group position={[3.2, 1.02, 1.15]} rotation={[0, -0.14, 0]}>
        {[0, 0.11, 0.22].map((y, index) => <mesh key={y} position={[0, y, 0]}><boxGeometry args={[1.25 - index * 0.08, 0.1, 0.85]} /><Material color={index === 1 ? COPPER : CREAM} /></mesh>)}
      </group>
      <Plant position={[-4.25, 0.9, -0.5]} scale={1.05} />
    </group>
  );
}

function CameraRig({ reduceMotion }) {
  const pointer = useRef({ x: 0, y: 0 });
  const lookAt = useRef(new Vector3(0, 1.65, -0.6));
  const positions = useMemo(() => [
    new Vector3(-0.2, 2.5, 8.2),
    new Vector3(1.2, 2.25, 6.5),
    new Vector3(-1.45, 2.0, 5.65),
    new Vector3(1.5, 2.05, 6.0),
    new Vector3(0.15, 2.45, 7.45),
  ], []);
  const targets = useMemo(() => [
    new Vector3(0, 1.65, -0.7),
    new Vector3(-0.65, 1.85, -0.3),
    new Vector3(1.75, 1.5, 0.1),
    new Vector3(-1.2, 1.45, -0.4),
    new Vector3(0, 1.75, -1.1),
  ], []);

  useEffect(() => {
    if (reduceMotion) return undefined;
    const move = event => {
      pointer.current.x = (event.clientX / window.innerWidth - 0.5) * 2;
      pointer.current.y = (event.clientY / window.innerHeight - 0.5) * 2;
    };
    window.addEventListener('pointermove', move, { passive: true });
    return () => window.removeEventListener('pointermove', move);
  }, [reduceMotion]);

  useFrame(({ camera }, delta) => {
    const available = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
    const progress = reduceMotion ? 0 : MathUtils.clamp(window.scrollY / available, 0, 1);
    const scaled = progress * (positions.length - 1);
    const index = Math.min(positions.length - 2, Math.floor(scaled));
    const raw = scaled - index;
    const blend = raw * raw * (3 - 2 * raw);
    const destination = positions[index].clone().lerp(positions[index + 1], blend);
    const target = targets[index].clone().lerp(targets[index + 1], blend);

    if (!reduceMotion) {
      destination.x += pointer.current.x * 0.16;
      destination.y -= pointer.current.y * 0.09;
      target.x += pointer.current.x * 0.08;
    }

    camera.position.x = MathUtils.damp(camera.position.x, destination.x, 3.5, delta);
    camera.position.y = MathUtils.damp(camera.position.y, destination.y, 3.5, delta);
    camera.position.z = MathUtils.damp(camera.position.z, destination.z, 3.5, delta);
    lookAt.current.x = MathUtils.damp(lookAt.current.x, target.x, 4, delta);
    lookAt.current.y = MathUtils.damp(lookAt.current.y, target.y, 4, delta);
    lookAt.current.z = MathUtils.damp(lookAt.current.z, target.z, 4, delta);
    camera.lookAt(lookAt.current);
  });

  return null;
}

export default function OfficeScene({ mobile = false, reduceMotion = false }) {
  return (
    <>
      <color attach="background" args={['#17130f']} />
      <fog attach="fog" args={['#17130f', 13, 35]} />
      <ambientLight intensity={mobile ? 1.05 : 0.72} color="#d9c6af" />
      <hemisphereLight intensity={0.8} color="#cce5e8" groundColor="#3a2417" />
      <directionalLight
        position={[4, 7, 5]}
        intensity={2.15}
        color="#f2d3aa"
        castShadow={!mobile}
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
      />
      <pointLight position={[-3.8, 3.9, -2.8]} intensity={18} distance={7} color="#f0b66f" />
      <mesh position={[0, -0.08, 0]} receiveShadow>
        <boxGeometry args={[12.5, 0.16, 15]} />
        <Material color="#59402f" roughness={0.82} />
      </mesh>
      <mesh position={[-6.05, 2.7, 1]}><boxGeometry args={[0.22, 5.5, 12]} /><Material color="#3b2a21" /></mesh>
      <mesh position={[6.05, 2.7, 1]}><boxGeometry args={[0.22, 5.5, 12]} /><Material color="#3b2a21" /></mesh>
      <WindowWall simple={mobile} />
      <Shelves />
      <Desk simple={mobile} />
      {!mobile && (
        <Float speed={0.65} rotationIntensity={0.025} floatIntensity={0.03}>
          <mesh position={[3.9, 4.35, -3.6]}>
            <sphereGeometry args={[0.23, 18, 12]} />
            <meshStandardMaterial color="#f7d39c" emissive="#f2a958" emissiveIntensity={2.2} />
          </mesh>
        </Float>
      )}
      <CameraRig reduceMotion={reduceMotion} />
    </>
  );
}
