import { Component, Suspense, useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { useReducedMotion } from 'framer-motion';
import OfficeScene from './OfficeScene';

class SceneErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }

  static getDerivedStateFromError() {
    return { failed: true };
  }

  render() {
    if (this.state.failed) return <OfficeFallback />;
    return this.props.children;
  }
}

function OfficeFallback() {
  return <div className="office-fallback" role="img" aria-label="Escritório contemporâneo da AVLS" />;
}

function canRenderWebGL() {
  try {
    const canvas = document.createElement('canvas');
    return Boolean(window.WebGL2RenderingContext && canvas.getContext('webgl2'));
  } catch {
    return false;
  }
}

export default function OfficeExperience() {
  const reduceMotion = useReducedMotion();
  const [mobile, setMobile] = useState(false);
  const [available, setAvailable] = useState(true);

  useEffect(() => {
    const media = window.matchMedia('(max-width: 760px)');
    const update = () => setMobile(media.matches);
    update();
    setAvailable(canRenderWebGL() && !navigator.connection?.saveData);
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  if (!available || reduceMotion) {
    return <div className="office-background" aria-hidden="true"><OfficeFallback /></div>;
  }

  return (
    <div className="office-background" aria-hidden="true">
      <SceneErrorBoundary>
        <Canvas
          shadows={!mobile}
          dpr={mobile ? 1 : [1, 1.5]}
          camera={{ position: [0, 2.45, 8.2], fov: mobile ? 52 : 45, near: 0.1, far: 70 }}
          gl={{ antialias: !mobile, alpha: false, powerPreference: 'high-performance' }}
          onCreated={({ gl }) => {
            gl.domElement.addEventListener('webglcontextlost', () => setAvailable(false), { once: true });
          }}
        >
          <Suspense fallback={null}>
            <OfficeScene mobile={mobile} reduceMotion={Boolean(reduceMotion)} />
          </Suspense>
        </Canvas>
      </SceneErrorBoundary>
      <div className="office-cinematic-overlay" />
    </div>
  );
}
